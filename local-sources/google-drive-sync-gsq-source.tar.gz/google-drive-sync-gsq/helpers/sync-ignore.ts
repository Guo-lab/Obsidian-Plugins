import ignore, { type Ignore } from 'ignore';
import type ObsidianGoogleDrive from '../main';

export const IGNORE_FILE = 'google-drive-sync.ignore';
type State = { text: string; matcher: Ignore; previous: Ignore; changed: boolean; protectedPaths: string[] };
const states = new WeakMap<ObsidianGoogleDrive, State>();

// A sync uses one local snapshot. The control file itself is never transferred.
export async function loadSyncIgnore(t: ObsidianGoogleDrive) {
	const adapter = t.app.vault.adapter;
	const text = (await adapter.exists(IGNORE_FILE))
		? await adapter.read(IGNORE_FILE)
		: '';
	states.set(t, {
		text,
		matcher: ignore({ ignorecase: false }).add(text),
		previous: ignore({ ignorecase: false }).add(t.settings.lastIgnoreRules ?? ''),
		changed: text !== (t.settings.lastIgnoreRules ?? ''),
		protectedPaths: [],
	});
	const state = states.get(t)!;
	state.protectedPaths = Object.values(t.settings.driveIdToPath).filter((path) => isSyncIgnored(t, path));
	for (const path of Object.keys(t.settings.operations)) {
		if (isSyncIgnored(t, path, t.settings.operations[path] === 'delete') || wasSyncIgnored(t, path)) {
			delete t.settings.operations[path];
		}
	}
}

export function ignoreRulesChanged(t: ObsidianGoogleDrive) {
	return states.get(t)?.changed ?? false;
}

export function wasSyncIgnored(t: ObsidianGoogleDrive, path: string, folder = false) {
	return !!path && path !== '/' && (states.get(t)?.previous.ignores(folder ? path.replace(/\/$/, '') + '/' : path) ?? false);
}

export function checkpointIgnoreRules(t: ObsidianGoogleDrive) {
	const state = states.get(t);
	if (state) t.settings.lastIgnoreRules = state.text;
}

export function isSyncIgnored(t: ObsidianGoogleDrive, path: string, folder = false) {
	if (path === IGNORE_FILE) return true;
	// Keep this custom build, credentials, and per-device sync state local.
	// A full rescan must not replace it with an older cloud plugin binary.
	if (path === t.app.vault.configDir + '/community-plugins.json') return true;
	for (const id of ['google-drive-sync', 'google-drive-sync-gsq']) {
		const pluginPath = t.app.vault.configDir + '/plugins/' + id;
		if (path === pluginPath || path.startsWith(pluginPath + '/')) return true;
	}
	if (!path || path === '/') return false;
	return states.get(t)?.matcher.ignores(folder ? path.replace(/\/$/, '') + '/' : path) ?? false;
}

// Deleting a Drive/local folder is recursive. Preserve ancestors of ignored
// content, including remote files missing locally and hidden config files.
export function canDeleteSyncPath(t: ObsidianGoogleDrive, path: string) {
	if (isSyncIgnored(t, path, true)) return false;
	const prefix = path.replace(/\/$/, '') + '/';
	const paths = [
		IGNORE_FILE,
		t.app.vault.configDir + '/plugins/google-drive-sync/main.js',
		t.app.vault.configDir + '/plugins/google-drive-sync-gsq/main.js',
		...(states.get(t)?.protectedPaths ?? []),
		...Object.values(t.settings.driveIdToPath),
		...t.app.vault.getAllLoadedFiles().map((file) => file.path),
	];
	return !paths.some((child) => child.startsWith(prefix) && isSyncIgnored(t, child));
}
