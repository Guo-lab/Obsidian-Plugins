import { Modal, Notice, Setting } from 'obsidian';
import type ObsidianGoogleDrive from '../main';
import { IGNORE_FILE, loadSyncIgnore } from './sync-ignore';

export async function openIgnoreEditor(t: ObsidianGoogleDrive) {
	try {
		const adapter = t.app.vault.adapter;
		let text = (await adapter.exists(IGNORE_FILE)) ? await adapter.read(IGNORE_FILE) : '';
		const modal = new Modal(t.app);
		modal.setTitle('Edit sync exclusion rules');
		modal.contentEl.createEl('p', {
			text: `${IGNORE_FILE} — one gitignore pattern per line. Local to this device. Excluded files are kept on both sides.`,
		});
		new Setting(modal.contentEl).addTextArea((input) => {
			input.inputEl.rows = 14;
			input.inputEl.cols = 55;
			input.setPlaceholder('*.mp4\nVideos/\n/private-note.md\n# Comments start with #');
			input.setValue(text).onChange((value) => { text = value; });
		});
		new Setting(modal.contentEl)
			.addButton((button) => button.setButtonText('Cancel').onClick(() => modal.close()))
			.addButton((button) => button.setButtonText('Save rules').setCta().onClick(async () => {
				if (t.syncing) {
					new Notice('Wait for the current sync to finish before saving rules.');
					return;
				}
				try {
					await adapter.write(IGNORE_FILE, text);
					await loadSyncIgnore(t);
					modal.close();
					new Notice('Exclusion rules saved. They apply to the next sync.');
				} catch (error) {
					new Notice('Could not save exclusion rules.');
					console.error('Google Drive exclusion rules could not be saved', error);
				}
			}));
		modal.open();
	} catch (error) {
		new Notice('Could not read exclusion rules.');
		console.error('Google Drive exclusion rules could not be opened', error);
	}
}
