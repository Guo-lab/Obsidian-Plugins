# Google Drive Sync GSQ

基于 RichardX366/Obsidian-Google-Drive 3.1.1 扩展；GSQ 版本号为 1.0.1，使用独立 ID `google-drive-sync-gsq`、独立安装目录和独立设置。原版保留并停用，GSQ 版启用。官方更新不会覆盖 GSQ 版。两者不要同时启用。

## 规则文件

在仓库根目录放置 **文件** `google-drive-sync.ignore`，不是文件夹。安装包附带的示例默认排除大小写两种 MP4 扩展名。

也可通过设置 → Google Drive Sync GSQ → Sync exclusion rules → Edit rules 编辑。命令面板提供 Edit sync exclusion rules。保存不会立即发起同步；下一次同步读取新规则。

```gitignore
# 排除任意位置的 MP4
*.mp4
*.MP4

# 排除根目录下的一整个文件夹
/60-Resources/Courses/GT-2026F-ME6404/Recordings/

# 排除根目录下的单个文件
/private-note.md

# 允许一个例外
!demo.mp4
```

采用 npm `ignore` 的 gitignore 匹配语义：支持注释、`*`、`?`、`**`、目录规则和 `!` 例外；规则区分大小写。父目录被排除时，需先用例外规则重新包含父目录，才能重新包含其中的文件。不是 Git 的全套机制：仅读取根目录这一份文件，不读取嵌套 `.gitignore`，不支持文件大小条件。

## 同步行为

- 排除规则适用于上传、下载及同步引发的删除；重置也保留排除的文件。
- 加入规则不会删除已上传的视频，也不会释放云端或 iPad 的现有占用。清理已有副本应单独处理。
- 删除父文件夹时，只要里面有已知的排除内容，就保留父文件夹，避免递归删除波及这些内容。
- 修改规则后，会重新扫描远端文件元数据，以发现之前排除的旧文件。第一次使用规则可能较慢。
- 取消排除后，如果本地仍有该文件，会沿用插件的本地优先策略并安排上传；本地没有的文件会重新下载。
- 规则文件、原版与 GSQ 的插件目录，以及插件启用列表 `community-plugins.json` 始终不参与同步。这样云端旧版插件不会覆盖修改版，登录凭证和同步进度也留在各设备本地。其他插件文件和配置仍沿用原来的同步逻辑，但各设备分别决定启用哪些插件。
- 每台设备独立配置规则。需要 iPad 同样排除视频时，必须在第一次连接云端之前安装修改版并放好规则文件。不能只在电脑上加规则，然后在 iPad 上继续使用原版。
- 每次同步使用当时读取的规则。直接用外部编辑器在传输中改规则，下一轮才会生效；内置编辑器会阻止在同步过程中保存。
- 读取规则失败时取消本轮同步，避免在没有预期过滤的情况下继续。

## 电脑安装与回退

GSQ 安装到 `.obsidian/plugins/google-drive-sync-gsq/`。迁移时复制原设备的登录配置和同步基线，继续连接原云端仓库，不建立新的云端仓库。原插件的程序已恢复为原版 3.1.1，原设置保留。

电脑已配置原版停用、GSQ 启用。设置中显示 Google Drive Sync GSQ，并提供 Edit rules。

回退时先停用 GSQ 再启用原版；原版不会识别过滤规则，重新启用后视频可能恢复同步。备份保存在 `local-backups/`。

GSQ 不在社区目录，原插件的官方升级不会修改 GSQ 的安装目录；需要手动维护 GSQ 与官方新功能的合并。

## iPad 安装包

`dist/google-drive-sync-gsq.zip` 提供独立 GSQ 插件的程序文件、规则示例和本说明，不含登录凭证。

如果 iPad 尚无此仓库，`dist/Guo-lab-s-Obsidian-GSQ-iPad-starter.zip` 提供同名的空仓库模板，仅包含修改版插件和默认规则，没有笔记、视频或 Token。可在 iPad 文件 App 中将其解压到“我的 iPad → Obsidian”下，使 `Guo-lab-s-Obsidian` 成为该目录的直接子文件夹，然后在 Obsidian 中打开。不要放进 iCloud，也不要覆盖已有仓库。允许第三方插件并启用 Google Drive Sync GSQ，停用原版，在设置里确认 MP4 规则后，再粘贴 Token 开始首次下载。

如果已有 iPad 仓库，保留已有笔记，安装到 `.obsidian/plugins/google-drive-sync-gsq/` 的程序文件，并把规则文件放到仓库根目录；若 iPad 原来已配置原版，可在停用原版后把该设备的 `data.json` 复制到 GSQ 目录；不要复制电脑的同步状态来替代 iPad 的状态。

## 验证

`npm test`、`npm run build` 和 `npm run lint`。测试覆盖规则语义、排除上传与下载、删除保护、取消排除重新扫描、保留本地编辑及规则读取失败。测试使用模拟 Drive 请求，没有在你的云端执行上传、删除或重置。iPad 上的实际运行仍需在安装后确认。

## 1.0.1 修复

同步检查阶段显示实际阶段名称；成功、失败或内层拉取中止后，都会关闭本轮进度通知。修改排除规则会重新扫描元数据，但不再重复下载所有未变化的包含文件。

## Git 或 Google Drive 传到 iPad

Git commit 只保存本机版本；还要 push 到远端，再在 iPad 用 Git 客户端 pull 并放到仓库的正确目录。你当前仓库的 `.gitignore` 排除了 `.obsidian/plugins/`，所以普通 commit 不会包含 GSQ 插件。若决定用 Git 传安装文件，只跟踪 GSQ 的 `main.js`、`manifest.json`、`styles.css` 和规则文件，不跟踪 `data.json` 或同步状态。插件源码项目的 `main.js` 是构建产物，不会仅靠拉取源码自动安装。

可以把 GSQ ZIP 上传到 Google Drive 的普通文件夹，然后用 iPad 的 Drive/文件 App 下载。这个文件夹应在插件管理的同步仓库之外。使用上面的空仓库模板可以避免在文件 App 中手工创建隐藏的 `.obsidian` 目录。原版 Google Drive Sync 也能同步其他插件的程序和设置文件，但用它来做初次安装可能先下载全部视频，且可能传递电脑的 `data.json`。GSQ 自己则刻意排除了原版与 GSQ 的插件目录，不用它来同步自身程序。
