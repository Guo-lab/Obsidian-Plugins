import { describe, expect, it, vi } from 'vitest';
import { canDeleteSyncPath, checkpointIgnoreRules, IGNORE_FILE, ignoreRulesChanged, isSyncIgnored, loadSyncIgnore } from '../helpers/sync-ignore';

function pluginFor(text: string) {
	return {
		app: { vault: {
			configDir: 'settings',
			adapter: { exists: vi.fn(async () => true), read: vi.fn(async () => text) },
			getAllLoadedFiles: () => [{ path: 'Videos/keep.mp4' }],
		} },
		settings: { operations: {} as Record<string, 'create' | 'delete' | 'modify'>, driveIdToPath: {} as Record<string, string>, lastIgnoreRules: '' },
	};
}

describe('sync exclusion rules', () => {
	it('supports extensions, anchored paths, directories, comments, globstar and exceptions', async () => {
		const t = pluginFor('# comment\n*.mp4\n!important.mp4\n/Videos/\n/private.md\n**/cache/*.bin');
		await loadSyncIgnore(t as never);
		for (const path of ['clip.mp4', 'courses/clip.mp4', 'Videos/important.mp4', 'private.md', 'a/cache/raw.bin']) {
			expect(isSyncIgnored(t as never, path), path).toBe(true);
		}
		for (const path of ['important.mp4', 'a/important.mp4', 'a/private.md', 'notes.md', 'Videos']) {
			expect(isSyncIgnored(t as never, path), path).toBe(false);
		}
		expect(isSyncIgnored(t as never, 'Videos', true)).toBe(true);
	});

	it('never transfers the control file, even with a negation rule', async () => {
		const t = pluginFor(`!${IGNORE_FILE}`);
		await loadSyncIgnore(t as never);
		expect(isSyncIgnored(t as never, IGNORE_FILE)).toBe(true);
	});

	it('protects the custom plugin and its per-device credentials from self-overwrite', async () => {
		const t = pluginFor('!settings/**');
		await loadSyncIgnore(t as never);
		expect(isSyncIgnored(t as never, 'settings/plugins/google-drive-sync/main.js')).toBe(true);
		expect(isSyncIgnored(t as never, 'settings/plugins/google-drive-sync/data.json')).toBe(true);
		expect(isSyncIgnored(t as never, 'settings/plugins/google-drive-sync-gsq/main.js')).toBe(true);
		expect(isSyncIgnored(t as never, 'settings/plugins/google-drive-sync-gsq/data.json')).toBe(true);
		expect(isSyncIgnored(t as never, 'settings/community-plugins.json')).toBe(true);
		expect(isSyncIgnored(t as never, 'settings/plugins/other/main.js')).toBe(false);
	});

	it('clears excluded queued mutations without touching files', async () => {
		const t = pluginFor('*.mp4');
		t.settings.operations = { 'a.mp4': 'delete', 'b.mp4': 'modify', 'c.mp4': 'create', 'note.md': 'modify' };
		await loadSyncIgnore(t as never);
		expect(t.settings.operations).toEqual({ 'note.md': 'modify' });
	});

	it('protects ancestor folders of ignored local and remote files', async () => {
		const t = pluginFor('*.mp4');
		t.settings.driveIdToPath = { remote: 'Remote/video.mp4' };
		await loadSyncIgnore(t as never);
		delete t.settings.driveIdToPath.remote;
		expect(canDeleteSyncPath(t as never, 'Videos')).toBe(false);
		expect(canDeleteSyncPath(t as never, 'Remote')).toBe(false);
		expect(canDeleteSyncPath(t as never, 'Notes')).toBe(true);
	});

	it('detects rule changes until a successful sync checkpoints them', async () => {
		const t = pluginFor('*.mp4');
		await loadSyncIgnore(t as never);
		expect(ignoreRulesChanged(t as never)).toBe(true);
		checkpointIgnoreRules(t as never);
		await loadSyncIgnore(t as never);
		expect(ignoreRulesChanged(t as never)).toBe(false);
	});

	it('fails closed if an existing rule file cannot be read', async () => {
		const t = pluginFor('');
		t.app.vault.adapter.read.mockRejectedValueOnce(new Error('Permission denied'));
		await expect(loadSyncIgnore(t as never)).rejects.toThrow('Permission denied');
	});
});
